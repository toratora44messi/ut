#ifndef SINGLETON_C_H
#define SINGLETON_C_H
#include "IEnumDef.h"

class singletonC
{
private:
    singletonC(/* args */);
public:
    ~singletonC();
    static singletonC* createInstance();
    static singletonC* getIntance();
    int getAgeFFDB(char* name);
    int getAgeFBDB(char* name);
    int getAgeOTHERDB(char* name);

private:
    class CUserAge {
        public:
            CUserAge(char* name, int age); 
            ~CUserAge();
            char fName[128+1];
            int fAge;
    };

    static singletonC* fgC_Obj;
    CUserAge* fFFDB[3];
    CUserAge* fFBDB[3];  
    CUserAge* fOTHERDB[3];    

    void createDB();


};
#endif //SINGLETON_C_H