#ifndef SINGLETON_B_H
#define SINGLETON_B_H

#include "IEnumDef.h"

class singletonB
{
private:
    singletonB(/* args */);
public:
    ~singletonB();
    static singletonB* createInstance();
    static singletonB* getIntance();
    IEnumDef::E_UserType getName_B(char* name, int size);
    bool setName_B(char* name, int size, IEnumDef::E_UserType userType);
    void clearName_B();

private:
    static singletonB* fgB_Obj;
    char fName[128+1];
    IEnumDef::E_UserType fUserType;
};
#endif //SINGLETON_B_H
