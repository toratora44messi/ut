The documents are generated automatically during the build process. To generate the documents implicitly, run following commands :

```sh
cd build
make documents
```

The generated documents are stored in the html subdirectory. Open the [index.html](html/index.html) file to read. 