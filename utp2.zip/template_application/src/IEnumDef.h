#ifndef I_ENUM_DEF_H
#define I_ENUM_DEF_H

class IEnumDef
{
public:

    enum class E_UserType{
        eNull,
        eFF,
        eFB,
        eSDCC,
        eMax
    };

};
#endif //I_ENUM_DEF_H
