#ifndef TARGET_H
#define TARGET_H

class target
{
private:
/* data */
public:
    enum EType{
        eType_A,
        eType_B,
        eType_C
    };

    target();
    ~target();
    int getNum(target::EType type);
    bool getCurrentUserAge(int* age);
};
#endif //TARGET_H