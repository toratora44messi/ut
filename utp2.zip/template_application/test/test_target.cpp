#include <gtest/gtest.h>
#include "target.h"
#include "singletonA.h"
#include "singletonB.h"
#include "singletonC.h"
#include "IEnumDef.h"

// テストフィクスチャのセットアップ
class TargetTest : public ::testing::Test {
protected:
    void SetUp() override {
        // テストに必要な初期化処理を実行
        singletonA::createInstance();
        singletonB::createInstance();
        singletonC::createInstance();
    }

    void TearDown() override {
        // テスト終了後の後処理を実行
        // インスタンスの破棄などが必要な場合はここで行う
    }
};

// getCurrentUserAge()メソッドのテストケース
TEST_F(TargetTest, GetCurrentAge_Success) {
    // singletonB::setName_B()で値を設定する
    char name[128+1] = "ff_Messi";
    int len = (strlen(name) + 1);
    singletonB::createInstance();
    singletonB* obj_B = singletonB::getIntance();
    
    bool setNameResult = obj_B->setName_B(name, len, IEnumDef::E_UserType::eFF);

    target t;
    int age;
    bool result = t.getCurrentUserAge(&age);

    // テスト結果の検証
    EXPECT_TRUE(result);
    EXPECT_GE(age, 0);
}

TEST_F(TargetTest, GetCurrentAge_NullAgePointer) {
    target t;
    int* age = nullptr;
    bool result = t.getCurrentUserAge(age);

    // テスト結果の検証
    EXPECT_FALSE(result);
}

// getNum()メソッドのテストケース
TEST_F(TargetTest, GetNum_ValidType) {
    target t;
    int num = t.getNum(target::eType_A);

    // テスト結果の検証
    EXPECT_EQ(num, 16);
}

TEST_F(TargetTest, GetNum_InvalidType) {
    target t;
    int num = t.getNum(static_cast<target::EType>(999));

    // テスト結果の検証
    EXPECT_EQ(num, -1);
}

// テスト実行
int main(int argc, char** argv) {
    ::testing::InitGoogleTest(&argc, argv);
    return RUN_ALL_TESTS();
}
