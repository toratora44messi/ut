#include "singletonC.h"
#include <string.h>
#include <stdio.h>

singletonC* singletonC::fgC_Obj = 0;

singletonC::singletonC(/* args */)
{
    createDB();
}

singletonC::~singletonC()
{

}

singletonC* singletonC::createInstance()
{
    if (fgC_Obj != 0) {
        return fgC_Obj;
    }

    fgC_Obj = new singletonC();

    return fgC_Obj;
}

singletonC* singletonC::getIntance()
{
    printf("singletonC* singletonC::getIntance() fgC_Obj[%d] \n",fgC_Obj);
    return fgC_Obj;
}

int singletonC::getAgeFFDB(char* name)
{
    if (name == 0) {
        printf("getAgeFFDB name == 0\n");
        return -1; //ng
    }

    for(int i = 0; i < 3; i++) {
        if (strcmp(name, fFFDB[i]->fName)  == 0)
            return fFFDB[i]->fAge;
    }

    printf("getAgeFFDB no hit\n");
    return -1;
}

int singletonC::getAgeFBDB(char* name)
{
    if (name == 0) {
        return -1; //ng
    }

    for(int i = 0; i < 3; i++) {
        if (strcmp(name, fFBDB[i]->fName)  == 0)
            return fFBDB[i]->fAge;
    }

    return -1;
}

int singletonC::getAgeOTHERDB(char* name)
{
    if (name == 0) {
        return -1; //ng
    }

    for(int i = 0; i < 3; i++) {
        if (strcmp(name, fOTHERDB[i]->fName)  == 0)
            return fOTHERDB[i]->fAge;
    }

    return -1;
}

//private
void singletonC::createDB(){

    //ff
    fFFDB[0] = new CUserAge("ff_Messi", 35);
    fFFDB[1] = new CUserAge("ff_Mbappe" , 24);
    fFFDB[2] = new CUserAge("ff_Beckham", 48);
    
    //fb
    fFBDB[0] = new CUserAge("fb_LeBron", 38);
    fFBDB[1] = new CUserAge("fb_Jordan", 60);
    fFBDB[2] = new CUserAge("fb_Curry", 35);

    //sdcc
    fOTHERDB[0] = new CUserAge("ot_Tyson", 56);
    fOTHERDB[1] = new CUserAge("ot_GGG", 41);
    fOTHERDB[2] = new CUserAge("ot_Inoue", 31);
}

//private inner class
singletonC::CUserAge::CUserAge(char* name, int age)
{
    singletonC::CUserAge::fAge = age;
    int len = sizeof(singletonC::CUserAge::fName);
    memset(singletonC::CUserAge::fName, 0, len);
    strncpy(singletonC::CUserAge::fName, name, len-1);
}

singletonC::CUserAge::~CUserAge(){
    
}

