#include "singletonB.h"
#include <string.h>
#include <stdio.h>

singletonB* singletonB::fgB_Obj = 0;

singletonB::singletonB(/* args */)
    : fUserType(IEnumDef::E_UserType::eNull)
{
}

singletonB::~singletonB()
{
}

singletonB* singletonB::createInstance()
{
    printf("singletonB* singletonB::createInstance()\n");
    if (fgB_Obj != 0) {
        printf("singletonB* singletonB::createInstance() fgB_Obj != 0 \n");
        return fgB_Obj;
    }

    fgB_Obj = new singletonB();
    printf("singletonB* singletonB::createInstance() fgB_Obj[%d] \n",fgB_Obj);
    return fgB_Obj;
}

singletonB* singletonB::getIntance()
{
    printf("singletonB* singletonB::getIntance() fgB_Obj[%d] \n",fgB_Obj);
    return fgB_Obj;
}
    
IEnumDef::E_UserType singletonB::getName_B(char* name, int size)
{
    if(name == 0){
        return IEnumDef::E_UserType::eNull; //ng;
    }
    if(size < 1 ){
        return IEnumDef::E_UserType::eNull; //ng
    }

    memset(name, 0, size);
    strncpy(name, fName, size-1);
    return fUserType;
}

bool singletonB::setName_B(char* name, int size, IEnumDef::E_UserType userType)
{
    printf("singletonB::setName_B char[%s] size[%d] type[%d]\n", name, size, userType);
    if (name == nullptr) {
        return false;
    }
    if (size < 1 || size > 128) {
        return false;
    }
    if (userType >= IEnumDef::E_UserType::eMax) {
        return false;
    }

    memset(fName, 0, sizeof(fName));
    strncpy(fName, name, sizeof(fName) - 1);
    fUserType = userType;
    printf("singletonB::setName_B fName[%s] type[%d]\n", fName, fUserType);
    return true;
}

void singletonB::clearName_B()
{
    memset(fName, 0, sizeof(fName));
}