#include <iostream>
#include <thread>

int main()
{
        return 0;
}