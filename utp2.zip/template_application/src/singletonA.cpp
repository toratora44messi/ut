#include "singletonA.h"
#include <stdio.h>

singletonA* singletonA::fgA_Obj = 0;

singletonA::singletonA(/* args */) 
{
}

singletonA::~singletonA()
{
}

singletonA* singletonA::createInstance()
{
    printf("singletonA* singletonA::createInstance()\n");
    if (fgA_Obj != 0) {
        printf("singletonA* singletonA::createInstance() fgA_Obj != 0 \n");
        return fgA_Obj;
    }

    fgA_Obj = new singletonA();
    printf("singletonA* singletonA::createInstance() fgA_Obj[%d] \n",fgA_Obj);
    return fgA_Obj;
}

singletonA* singletonA::getIntance()
{
    printf("singletonA* singletonA::getIntance() fgA_Obj[%d] \n",fgA_Obj);
    return fgA_Obj;
}

bool singletonA::getNumber(int* number)
{
    if (number == 0)
        return false;

    if (*number < 18) {
        *number += 5;   // Adds 5 to the value pointed by 'number'
    } else {
        *number += 10;  // Adds 10 to the value pointed by 'number'
    }

    return true;
}


