#include "target.h"
#include "singletonA.h"
#include "singletonB.h"
#include "singletonC.h"
#include "IEnumDef.h"
#include <string.h>
#include <stdio.h>

target::target()
{
}

target::~target()
{
}

int target::getNum(target::EType type){
    int num;
    switch(type) {
    case target::eType_A:
        num = 11;
        break;
    case target::eType_B:
        num = 18;
        break;
    case target::eType_C:
        num = 100;
        break;
    default:
        return -1;
    }
    bool ret = singletonA::getIntance()->getNumber(&num);

    if (!ret) {
        num = -1;
    }
    
    return num;
}

bool target::getCurrentUserAge(int* age)
{
    printf("getCurrentUserAge\n");
    if (age == 0){
        printf("getCurrentUserAge age == 0 \n");
        return false;
    }

    char name[128+1];
    memset(name, 0, sizeof(name));


    singletonB* obj_B = singletonB::getIntance();
    if (obj_B ==0){
        printf("getCurrentUserAge obj_B ==0 \n");
        return false;
    }

    IEnumDef::E_UserType userType = obj_B->getName_B(name, sizeof(name)-1);
     printf("getCurrentUserAge userType[%d] name[%s]\n", userType, &name);
    int ageBuf = -1;
    singletonC* obj_C = singletonC::getIntance();
    switch(userType)
    {
    case IEnumDef::E_UserType::eFF:
        ageBuf = obj_C->getAgeFFDB(name);
        printf("getAgeFFDB ageBuf[%d]\n", ageBuf);
        break;
    case IEnumDef::E_UserType::eFB:
        ageBuf = obj_C->getAgeFBDB(name);
        printf("getAgeFBDB ageBuf[%d]\n", ageBuf);
        break;
    case IEnumDef::E_UserType::eSDCC:
        ageBuf = obj_C->getAgeOTHERDB(name);
        printf("getAgeOTHERDB ageBuf[%d]\n", ageBuf);
        break;
    default:
        break;
    }

    if (ageBuf == -1){
        printf("getCurrentUserAge ageBuf == -1 \n");
        return false;
    }
    
    *age = ageBuf;
    return true;
}
